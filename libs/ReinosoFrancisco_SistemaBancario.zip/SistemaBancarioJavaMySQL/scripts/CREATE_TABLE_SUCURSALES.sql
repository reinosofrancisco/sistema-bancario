CREATE TABLE `sistema_bancario`.`SUCURSALES` (
  `numeroSucursal` INT NOT NULL,
  `nombreSucursal` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`numeroSucursal`));
