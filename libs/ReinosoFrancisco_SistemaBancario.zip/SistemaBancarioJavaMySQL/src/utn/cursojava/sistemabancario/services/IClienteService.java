package utn.cursojava.sistemabancario.services;

import utn.cursojava.sistemabancario.models.Cliente;

public interface IClienteService {

    void addCliente(Cliente cliente);


}
